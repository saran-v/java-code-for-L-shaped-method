package com.project.optimizer.beans;

import java.util.ArrayList;

public interface InputParam {
	

}
