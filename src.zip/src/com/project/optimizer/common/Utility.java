
package com.project.optimizer.common;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.project.optimizer.beans.ParameterBean;


/**
 * Class for utility functions used for model construction
 * @author j1007420
 */
public class Utility
{	
		
}
